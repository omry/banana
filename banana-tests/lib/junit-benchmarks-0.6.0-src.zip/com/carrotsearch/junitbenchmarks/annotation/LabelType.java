package com.carrotsearch.junitbenchmarks.annotation;

/**
 * X-axis label type.
 */
public enum LabelType
{
    RUN_ID,
    CUSTOM_KEY,
    TIMESTAMP
}
